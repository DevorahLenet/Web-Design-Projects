
    <div id="footer">
        &copy; Devorah Sachs

        <ul class="nav" style="background-color:rgb(83, 221, 231);">
                    <li><a href="contact_us.php">Contact</a></li>
                    <li><a href="createaccount.php">Create Account</a></li>
                    <li><a href="jobs.php">See Jobs</a></li> 
                    <li><a href="howitworks.php">How it Works</a></li> 
                    <li><a href="home.php">Home</a></li> 
                </ul>
    </div>
</body>
</html>