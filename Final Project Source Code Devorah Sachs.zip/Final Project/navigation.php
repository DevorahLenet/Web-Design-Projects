            <div class="nav">
                <ul class="nav">
                    <li><a href="contact_us.php">Contact</a></li>
                    <li><a href="https://cdlwebsysdev.esc-atsystems.net/devorah_sachs948/Final%20Project/createaccount.php">Create Account</a></li>
                    <li><a href="https://cdlwebsysdev.esc-atsystems.net/devorah_sachs948/Final%20Project/jobs.php">See Jobs</a></li> 
                    <li><a href="https://cdlwebsysdev.esc-atsystems.net/devorah_sachs948/Final%20Project/howitworks.php">How it Works</a></li> 
                    <li><a href="https://cdlwebsysdev.esc-atsystems.net/devorah_sachs948/Final%20Project/home.php">Home</a></li>
                     
                </ul>
            </div>           
            
