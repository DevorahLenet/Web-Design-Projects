<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Final Project Website Navigation</title>

    <link rel="stylesheet" href="site.css">
</head>
<body>
            <div class="nav">
                <ul class="nav">
                    <li><a href="https://cdlwebsysdev.esc-atsystems.net/devorah_sachs948/Final%20Project/createaccount.php">Create Account</a></li>
                    <li><a href="https://cdlwebsysdev.esc-atsystems.net/devorah_sachs948/Final%20Project/jobs.php">See Jobs</a></li> 
                    <li><a href="https://cdlwebsysdev.esc-atsystems.net/devorah_sachs948/Final%20Project/howitworks.php">How it Works</a></li> 
                    <li><a href="https://cdlwebsysdev.esc-atsystems.net/devorah_sachs948/Final%20Project/home.php">Home</a></li> 
                </ul>
            </div>           
            
</body>
</html>