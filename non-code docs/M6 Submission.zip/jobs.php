<?php 
// Echo our XML declaration to the browser.  This must be done with an
// echo statement within PHP because otherwise the PHP processor on the 
// server will treat the starting <? as the beginning of a PHP block 
// instead of an XML block.
echo '<?xml version="1.0" encoding="UTF-8" ?>'; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>GiveGet Jobs Page</title>

<link rel="stylesheet" href="site.css">

<?php
// Start the PHP code block that will read the XML data file and convert it
// to a PHP object that we can then use when we build the xhtml content the'
// browser will be sent.


// Define a class for each <product> in the XML data file.  Each object will
// have properties (ie, variables) for each of the allowed tags or 
// sub-elements within the <product>.  It will also have a constructor method,
// and a simple method for updating a property.
class Job 
{
	// define the properties corresponding to valid attributes and sub-elements.
	var $id;
	var $job_name;
	var $category;
	var $location;
    var $date;
    var $skills_materials;
	var $volunteer_id;
	var $finished;
	
	// define an array listing which sub-element tags we want to process 
	// in this script.
	var $valid_tags = array ( 'JOB_NAME', 'CATEGORY', 'LOCATION', 'DATE', 'SKILLS_MATERIALS', 'VOLUNTEER_ID', 'FINISHED' );

	// this is the constructor function which assigns the product id property.
	function Job ($newID) 
	{
		$this->id = $newID;
	}
	
	// this function is used to add data to one of the other properties.
	function addData ($prop, $new_value) 
	{
		$prop = strtolower($prop);
		$this->$prop = $new_value;
	}
}


// Create an array to hold the products defined in the XML datafile.
$jobs_for_display = array(); //was $products?

// Use these variables to keep track of which product the XML parser is 
// currently processing and which element tag we are within.
$currentProductId = "";
$currentTag = "";


// This is a function to open the XML file and create the XML parser.
// It returns the file pointer and parser.
function create_parser ($filename) 
{
// open the XML data file in read only mode
	if ( !($fp = fopen($filename, "r")) ) {
    	die("Cannot locate XML data file: $filename");
	}
	
// initialize PHP's XML parser
	$parser = xml_parser_create();
	
// set the event handlers for the parser.  Notice that we're not processing
// any of the non-product content, so we don't need a default event handler.
	xml_set_element_handler($parser, 'startElement', 'endElement');
	xml_set_character_data_handler($parser, 'characterData');
	
// turn on case folding so all element and attribute names are uppercase.
	xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, true);
	
	return array($parser, $fp);
}


// This is a function to read in the data one line at a time and parse it.  
// When you call the parser, use an IF statement so you can report an error
// if it fails.
function parse ($parser, $fp) 
{
	while ($data = fgets($fp)) 
	{
		if ( !xml_parse($parser, $data, feof($fp)) ) 
		{
			die(sprintf("XML error: %s at line %d", 
			   xml_error_string(xml_get_error_code($parser)),  
			   xml_get_current_line_number($parser)));
		}
	}
}

// This function processes the open tag for each element, including
// its attributes.
function startElement($parser, $name, $attrs) 
{
	// make these global variables accessible within the function.
	global $jobs_for_display;
	global $currentProductId;
	global $currentTag;
	
	// set the global $currentTag entry to be the current tag being processed.
	$currentTag = $name;
	
	// If the element is a <product>, create a new object for it and add it 
	// to the $products array, using the id attribute of the <product> as the key.
	// When starting a new product, also set the $currentProductId variable.
	if ($name == "JOB")
	{
		// If there is a product without an ID attribute, exit and report an error.
		if ( !array_key_exists("ID", $attrs) )
		{
			die("Invalid element '$name' in XML file.  Missing ID attribute.");
		}
		
		$jobs_for_display[$attrs["ID"]] = new Job($attrs["ID"]);
		$currentProductId = $attrs["ID"];
	}
}


// This function processes the closing tag for each element.
function endElement($parser, $name) 
{
	// make these global variables accessible within the function.
	global $currentProductId;
	global $currentTag;
	
	// clear the current tag variable when the element is complete
	$currentTag = "";
	
	// When ending a product, also reset the $currentProductId variable.
	if ($name == "JOB") 
	{
		$currentProductId = "";
	}
}


// This function processes the data within the tags for each element.
function characterData($parser, $data) 
{
	// make these global variables accessible within the function.
	global $jobs_for_display;
	global $currentProductId;
	global $currentTag;
	
	// we only want to process the content from tags within a product, 
	// so check if the product id variable has been set yet.
	if ($currentProductId != "") 
	{
		// when parsing the contents of a product, check if the current
		// tag is one of the valid sub-elements defined in the object.
		// If so, add the content data of the sub-element as the value of
		// the corresponding property of the current object.
		if ( in_array($currentTag, $jobs_for_display[$currentProductId]->valid_tags) ) 
		{
			$jobs_for_display[$currentProductId]->addData($currentTag, $data);
		}
	}
}


// Everything we need is now defined, so try to create the parser.  
// If that succeeds, parse it to read in the XML data and populate
// the $products array, then free up the resources.
if ( list($parser, $fp) = create_parser('jobs.xml') ) 
{
	parse($parser, $fp);
	fclose($fp);
	xml_parser_free($parser);
}

// Our data is now ready to be used.  Closing the PHP block.
?>

</head>

<body>
<?php
    require 'header.php';
    require 'navigation.php';

?>
<div class="page_container">
	<h1>Open Jobs</h1>
	<p>The jobs below are waiting for some wonderful person (like you ;) to get 'em done.</p>

	<form action="jobs.php" method="get">
		<span class="form_header">Filter by Category:</span><br/>
		<select name="categories" id="filter_menu">
		<option value="all">All</option>
		<option value="errands">Errands</option>
		<option value="rides">Rides</option>
		<option value="childcare">Childcare</option>
		<option value="household help">Household Help</option>
		<option value="tutoring">Tutoring</option>
		<option value="visit">Visiting</option>
		<option value="carrying">Heavy Loads</option>
		<option value="event help">Event Prep</option>
		<option value="elder-care">Elder Care</option>
		<option value="food">Food Prep</option>
		</select>
		<input type="submit" id="form_btn" name="submit" value="Filter"/>
	</form>

	<?php 
		if(isset($_GET['submit'])){
			global $selected_value;
			$selected_value = $_GET['categories'];

			foreach ($jobs_for_display as $job_to_display)
				{
					if($job_to_display->volunteer_id == 0){
						if($selected_value == 'all'){
							require 'jobs_display.php';
						}elseif($job_to_display->category == $selected_value){
							require 'jobs_display.php';
						}
					}
				}
		}
	?>
</div>


</body>
</html>