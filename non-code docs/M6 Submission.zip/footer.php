<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>final project footer</title>
    
    <link rel="stylesheet" href="site.css">
</head>
<body>
    <div id="footer">
        &copy Devorah Sachs

        <ul class="nav" style="background-color:rgb(83, 221, 231);">
                    <li><a href="#">Create Account</a></li>
                    <li><a href="#">See Jobs</a></li> 
                    <li><a href="#">How it Works</a></li> 
                    <li><a href="#">Home</a></li> 
                </ul>
    </div>
</body>
</html>