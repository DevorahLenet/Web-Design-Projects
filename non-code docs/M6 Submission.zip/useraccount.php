<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GiveGet Account</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="useraccount.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="site.css">

</head>

<body>
<?php
    require 'header.php';
    require 'navigation.php';

?>

<div id="account_container">
    <div id="side_nav"> <!--side navigation bar, allows user to choose between profile and jobs list-->    
        <div id="btn_profile" class="profile_button" onclick="displayProfile()">Profile</div>
        <div id="btn_jobs" class="profile_button" onclick="displayJobsList()">My Jobs</div>
        <div id="btn_request" class="profile_button" onclick="displayRequestPage()">Create Request</div>
        <div id="btn_logout" class="profile_button" onclick="signOut1()">Sign Out</div>
    </div>

    <div id="profile_container"> <!--displays user's profile information-->
        <h1 class="profile_title">User's Name</h1>
        <h2>My Info:</h2>
        <p>Email:</p>
        <p>Phone Number:</p>
        <p>Location:</p>
        <h2>About Me:</h2>
    </div>

    <div id="jobs_container"> <!--displays user's jobs list and job history list-->
        <h1 class="profile_title">My Jobs</h1>
    </div>

    <div id="request_page">
        <h1 class="profile_title">Create Request</h1>
        <form action="">
            <input type="submit" name="submit" value="submit"/>
        </form>
    </div>

</div>

<div><!--footer-->
<?php 
    require 'footer.php'; 
?>
</div>
    
</body>
</html>