
        <?php 
        if($job_to_display->finished == 0){//only display jobs that are still open or 
                                           //in progress (depending on where the display is)

        ?>
            <div id=job_frame>
            <form id="on_job_form" action="">
                <input type="checkbox" id="sign_up_chkbx" name="sign_up" />
                <label for="sign_up_chkbx">Sign Up</label><br/>
                <input type="checkbox" id="learn_more_chkbx" name="learn_more" />
                <label for="learn_more_chkbx">Learn more</label><br/>
                <input type="submit" value="Go"/>
            </form>
            <span id="job_title"><?php echo $job_to_display->job_name ?></span> 
            <span class="job_info_header">(<?php echo $job_to_display->category ?>)</span><br/><br/>
            <span class="job_info_header">Where: </span> 
            <span><?php echo $job_to_display->location ?></span><br/>
            <span class="job_info_header">When: </span> 
            <span><?php echo $job_to_display->date ?></span><br/>
            <span class="job_info_header">Skills/Materials Needed: </span>
            <span><?php echo $job_to_display->skills_materials ?></span>

        </div>

        <?php
        }
        ?>
        
