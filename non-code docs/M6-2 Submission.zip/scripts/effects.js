$(document).ready(function(){
    //sign in button in header
    $("#signin_btn").mouseover(function(){
        $("#signin_btn").css("background-color", "rgb(83, 194, 231)");
      });

    $("#signin_btn").mouseout(function(){
        $("#signin_btn").css("background-color", "rgb(83, 221, 231)");
    });

    //form button in Jobs page
    $("#form_btn").mouseover(function(){
        $("#form_btn").css("background-color", "rgb(83, 194, 231)");
      });

    $("#form_btn").mouseout(function(){
        $("#form_btn").css("background-color", "rgb(83, 221, 231)");
    });

    //buttons on body of home page
    $("#home_to_jobs_page_btn").mouseover(function(){
      $("#home_to_jobs_page_btn").css("background-color", "rgb(83, 194, 231)");
    });

  $("#home_to_jobs_page_btn").mouseout(function(){
      $("#home_to_jobs_page_btn").css("background-color", "rgb(83, 221, 231)");
  });

  $("#home_to_create_account_btn").mouseover(function(){
    $("#home_to_create_account_btn").css("background-color", "rgb(83, 194, 231)");
  });

  $("#home_to_create_account_btn").mouseout(function(){
      $("#home_to_create_account_btn").css("background-color", "rgb(83, 221, 231)");
  });

  //button on how it works page
  $("#howitworks_to_create_account_btn").mouseover(function(){
    $("#howitworks_to_create_account_btn").css("background-color", "rgb(83, 194, 231)");
  });

  $("#howitworks_to_create_account_btn").mouseout(function(){
      $("#howitworks_to_create_account_btn").css("background-color", "rgb(83, 221, 231)");
  });

    //side nav buttons in profile
    $("#btn_profile").mouseover(function(){
        $("#btn_profile").css("background-color", "rgb(83, 194, 231)");
      });

    $("#btn_profile").mouseout(function(){
        $("#btn_profile").css("background-color", "rgb(83, 221, 231)");
    });

    $("#btn_jobs").mouseover(function(){
        $("#btn_jobs").css("background-color", "rgb(83, 194, 231)");
      });

    $("#btn_jobs").mouseout(function(){
        $("#btn_jobs").css("background-color", "rgb(83, 221, 231)");
    });

    $("#btn_request").mouseover(function(){
        $("#btn_request").css("background-color", "rgb(83, 194, 231)");
      });

    $("#btn_request").mouseout(function(){
        $("#btn_request").css("background-color", "rgb(83, 221, 231)");
    });

    $("#btn_logout").mouseover(function(){
        $("#btn_logout").css("background-color", "rgb(83, 194, 231)");
      });

    $("#btn_logout").mouseout(function(){
        $("#btn_logout").css("background-color", "rgb(83, 221, 231)");
    });
});


